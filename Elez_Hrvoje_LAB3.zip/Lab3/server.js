const express = require('express');
const path = require('path');
const app = express();

app.use(express.static(path.join(__dirname, 'public')));
app.set('views', path.join(__dirname, 'views'));
app.set('view_engine', 'ejs');
app.use(express.urlencoded({extended:true}));

const indexRoute = require('./routes/index.router');
const dataTableAll = require('./routes/datatable_all.router');
const openAPIRoute = require('./routes/openAPI.router');

app.use('/', indexRoute);
app.use('/datatable_all', dataTableAll);
app.use('/openAPI', openAPIRoute);

// this is default in case of unmatched routes
app.use(function (req, res) {
    // Invalid request
    res.set('content-type', 'application/json');
    res.status(404).send({
        status: "Not Found",
        message: `Wrong PATH!!!`,
        response : null
    });
});

app.listen(3000);
console.log("Server started");

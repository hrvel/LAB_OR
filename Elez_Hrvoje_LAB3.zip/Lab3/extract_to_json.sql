WITH 
klub AS (
	SELECT *
	FROM public."Klubovi" as k
),

klub_bez_ID AS 
(
	SELECT kl."Ime_kluba", kl."Godina_osnutka_kluba", kl."Trener", kl."Stadion"
	FROM "Klubovi" as kl
),

član AS (
SELECT "Ime_članice" as Država,
	"Predsjednik_članice" as Predsjednik,
	"Godina_osnutka_članice" as Godina_Osnutka,
	"Godina_pristupanja_članice" as Godina_Pristupanja,
	"fk_KonfederacijaID" as konf_ID,
	json_agg(json_build_object('Klub', ke."Ime_kluba", 'Godina_osnutka', ke."Godina_osnutka_kluba", 'Trener',  ke."Trener", 'Stadion',  ke."Stadion")) AS Klubovi
FROM "Članice" cl
JOIN klub ke
ON (cl."ČlanicaID" = ke."ID_članice")
GROUP BY "Ime_članice","Predsjednik_članice","Godina_osnutka_članice","Godina_pristupanja_članice", "fk_KonfederacijaID"
),

 konfederacija_ag AS (
 SELECT "Ime_konfederacija" as konfederacija,
	 "Predsjednik_konfederacije" as predsjednik,
	 "Regija" as podrucje_djelovanja,
	 "Godina_osnutka_konfederacije" as godina_osnutka,
     json_agg(json_build_object('Država', cl_23.država,'Godina_osnutka', cl_23.godina_Osnutka, 'Predsjednik',  cl_23.predsjednik, 'Godina_pristupanja',  cl_23.godina_pristupanja, 'klubovi', cl_23.klubovi)) as Članovi
     FROm "Konfederacije" kf
     JOIN član cl_23
     ON (cl_23.konf_ID = kf."KonfederacijaID")
     GROUP BY "Ime_konfederacija", "Predsjednik_konfederacije", "Regija", "Godina_osnutka_konfederacije"
 )
\t
\a
\o '/home/elez/Desktop/FIFA.json' 
 SELECT json_agg(konfederacija_ag) from konfederacija_ag;
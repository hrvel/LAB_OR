const express = require('express');
const path = require('path');
const app = express();

app.use(express.static(path.join(__dirname, 'public')));
app.set('views', path.join(__dirname, 'views'));
app.set('view_engine', 'ejs');
app.use(express.urlencoded({extended:true}));

const indexRoute = require('./routes/index.router');
const dataTableAll = require('./routes/datatable_all.router');

app.use('/', indexRoute);
app.use('/datatable_all', dataTableAll)

app.listen(3000);
console.log("Server started");

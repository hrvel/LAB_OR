const express = require('express');
const app = express();
const path = require('path');
require('dotenv').config();
const { auth } = require('express-openid-connect');
const axios = require('axios');
const request = require('request');

app.set('views', path.join(__dirname, 'views'));
app.set('view_engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({extended:true}));

const indexRoute = require('./routes/index.router');
const dataTableAll = require('./routes/datatable_all.router');
const openAPIRoute = require('./routes/openAPI.router');
const req = require('express/lib/request');

let appLogged = false;
let prijava = false;

app.use(
    auth({
       authRequired: false,
       auth0Logout: true,
       issuerBaseURL: process.env.ISSUER_BASE_URL,
       baseURL: process.env.BASE_URL,
       clientID: process.env.CLIENT_ID, 
       secret: process.env.SECRET
    })
 )

 app.use('/', indexRoute);
 app.use('/datatable_all', dataTableAll);
 app.use('/openAPI', openAPIRoute);
 app.use('/profil', indexRoute);
 app.use('/osvjezi', dataTableAll);
 app.use('/odjava', indexRoute);
 app.use('/prijava', indexRoute);

// this is default in case of unmatched routes
app.use(function (req, res) {
    // Invalid request
    res.set('content-type', 'application/json');
    res.status(404).send({
        status: "Not Found",
        message: `Wrong PATH!!!`,
        response : null
    });
});

app.listen(3000);
console.log("Server started");

drop table temp_table;

create table temp_table as	
	SELECT Konf."Ime_konfederacija", Konf."Predsjednik_konfederacije", Konf."Regija", Konf."Godina_osnutka_konfederacije",
	"Članice"."Ime_članice","Članice"."Predsjednik_članice", "Članice"."Godina_osnutka_članice", "Članice"."Godina_pristupanja_članice",
	"Klubovi"."Ime_kluba","Klubovi"."Godina_osnutka_kluba","Klubovi"."Stadion","Klubovi"."Trener" 
	FROM "Konfederacije" as Konf 
	JOIN "Članice" ON  Konf."KonfederacijaID" = "Članice"."fk_KonfederacijaID" JOIN "Klubovi" ON "Klubovi"."ID_članice" = "Članice"."ČlanicaID";
\copy temp_table to '/home/elez/Desktop/FIFA.csv' csv header;
const express = require('express');
const router = express.Router();
const db = require('../db/db');

/*router.get('/', function (req, res, next) {
    res.render('index.ejs', {
        title: 'FIFA'
    });
});*/
let prijava = true;
let appLogged = false;

router.get('/', function (req, res, next) 
{
    console.log(req.oidc.isAuthenticated() ? 'Logged in' : 'Logged out');
    console.log(req.baseUrl);
    if(req.oidc.isAuthenticated() && prijava == true)
    {
        appLogged = true;
    }
    if(req.baseUrl === '/odjava')
    {
        if(appLogged === true) {
            appLogged = false;
            prijava = false;
            res.redirect('http://localhost:3000');
         } else {
            res.status(404).send({
                  status: "Not Found", 
                  message: `Niste prijavljeni u sustav!`,
               });
         }
    }
    else if(req.baseUrl === '/prijava')
    {
        prijava = true;
        console.log('prijava');
        res.redirect('/login');
    }
    else if(req.baseUrl === '/profil')
    {
        res.render('profil.ejs', {
            title: 'Profil',
            user: req.oidc.user
        });
    }

    else 
    {
        console.log("Prijava "  + appLogged);
        res.render('index.ejs', {
            title: 'FIFA',
            logged: req.oidc.isAuthenticated(),
            appLogged: appLogged,
            enableDownloadandFilter : false
        });
    }
});

module.exports = router;

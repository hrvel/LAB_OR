const express = require('express');
const router = express.Router();
const db = require('../db/db');

router.get('/', async function (req, res, next) {
        if(req.baseUrl === '/osvjezi')
        {
            var rows = (await db.query('SELECT Konf.\"Ime_konfederacija\", Konf.\"Predsjednik_konfederacije\", Konf.\"Regija\", Konf.\"Godina_osnutka_konfederacije\",\"Članice\".\"Ime_članice\",\"Članice\".\"Predsjednik_članice\", \"Članice\".\"Godina_osnutka_članice\", \"Članice\".\"Godina_pristupanja_članice\",\"Klubovi\".\"Ime_kluba\",\"Klubovi\".\"Godina_osnutka_kluba\",\"Klubovi\".\"Stadion\",\"Klubovi\".\"Trener\" FROM \"Konfederacije\" as Konf JOIN \"Članice\" ON  Konf.\"KonfederacijaID\" = \"Članice\".\"fk_KonfederacijaID\" JOIN \"Klubovi\" ON \"Klubovi\".\"ID_članice\" = \"Članice\".\"ČlanicaID\";')).rows;

            res.render('osvjezi.ejs', {
                title: 'FIFA OSVJEZI',
                data: rows
            });
        }
        else 
        {
            var csv_rows = (await db.query('	drop table temp_table; create table temp_table as SELECT Konf.\"Ime_konfederacija\", Konf.\"Predsjednik_konfederacije\", Konf.\"Regija\", Konf.\"Godina_osnutka_konfederacije\",\"Članice\".\"Ime_članice\",\"Članice\".\"Predsjednik_članice\", \"Članice\".\"Godina_osnutka_članice\", \"Članice\".\"Godina_pristupanja_članice\",\"Klubovi\".\"Ime_kluba\",\"Klubovi\".\"Godina_osnutka_kluba\",\"Klubovi\".\"Stadion\",\"Klubovi\".\"Trener\" FROM \"Konfederacije\" as Konf JOIN \"Članice\" ON  Konf.\"KonfederacijaID\" = \"Članice\".\"fk_KonfederacijaID\" JOIN \"Klubovi\" ON \"Klubovi\".\"ID_članice\" = \"Članice\".\"ČlanicaID\"; \copy temp_table to \'/home/elez/Desktop/FIFA_generated.csv\' csv header;')).rows;
            var rows = (await db.query('SELECT Konf.\"Ime_konfederacija\", Konf.\"Predsjednik_konfederacije\", Konf.\"Regija\", Konf.\"Godina_osnutka_konfederacije\",\"Članice\".\"Ime_članice\",\"Članice\".\"Predsjednik_članice\", \"Članice\".\"Godina_osnutka_članice\", \"Članice\".\"Godina_pristupanja_članice\",\"Klubovi\".\"Ime_kluba\",\"Klubovi\".\"Godina_osnutka_kluba\",\"Klubovi\".\"Stadion\",\"Klubovi\".\"Trener\" FROM \"Konfederacije\" as Konf JOIN \"Članice\" ON  Konf.\"KonfederacijaID\" = \"Članice\".\"fk_KonfederacijaID\" JOIN \"Klubovi\" ON \"Klubovi\".\"ID_članice\" = \"Članice\".\"ČlanicaID\";')).rows;
    
    
            res.render('datatable_all.ejs', {
                title: 'FIFA TABLIČNI PRIKAZ',
                data: rows
            });
        }

    

});

router.post('/', async function (req, res, next) {
    let vrijednost = req.body['query'];
    let parametar = req.body['parametar'];

    if (parametar == "sve") {
        if (vrijednost == "") {
            var rows = (await db.query('SELECT Konf."Ime_konfederacija", Konf."Predsjednik_konfederacije", Konf."Regija", Konf."Godina_osnutka_konfederacije", "Članice"."Ime_članice","Članice"."Predsjednik_članice", "Članice"."Godina_osnutka_članice", "Članice"."Godina_pristupanja_članice","Klubovi"."Ime_kluba","Klubovi"."Godina_osnutka_kluba","Klubovi"."Stadion","Klubovi"."Trener" FROM "Konfederacije" as Konf JOIN "Članice" ON  Konf."KonfederacijaID" = "Članice"."fk_KonfederacijaID" JOIN "Klubovi" ON "Klubovi"."ID_članice" = "Članice"."ČlanicaID";', [])).rows;
        } else {
            if (parseInt(vrijednost)) {
                vrije = parseInt(vrijednost);
                var rows = (await db.query('SELECT Konf."Ime_konfederacija", Konf."Predsjednik_konfederacije", Konf."Regija", Konf."Godina_osnutka_konfederacije", 	"Članice"."Ime_članice","Članice"."Predsjednik_članice", "Članice"."Godina_osnutka_članice", "Članice"."Godina_pristupanja_članice", 	"Klubovi"."Ime_kluba","Klubovi"."Godina_osnutka_kluba","Klubovi"."Stadion","Klubovi"."Trener"  	FROM "Konfederacije" as Konf JOIN "Članice" ON  Konf."KonfederacijaID" = "Članice"."fk_KonfederacijaID" JOIN "Klubovi" ON "Klubovi"."ID_članice" = "Članice"."ČlanicaID" WHERE Konf."Godina_osnutka_konfederacije" = ' + vrijednost + ' OR Članice."Godina_pristupanja_članice" = ' + vrijednost + ' OR "Klubovi"."Godina_osnutka_kluba" = ' + vrijednost + 'OR Članice."Godina_osnutka_članice" LIKE \'' + vrijednost + '\' ;', [])).rows;
            } else {
                vrijednost = "\'" + vrijednost + "\'";
                var rows = (await db.query('SELECT Konf."Ime_konfederacija", Konf."Predsjednik_konfederacije", Konf."Regija", Konf."Godina_osnutka_konfederacije", 	"Članice"."Ime_članice","Članice"."Predsjednik_članice", "Članice"."Godina_osnutka_članice", "Članice"."Godina_pristupanja_članice", 	"Klubovi"."Ime_kluba","Klubovi"."Godina_osnutka_kluba","Klubovi"."Stadion","Klubovi"."Trener"  	FROM "Konfederacije" as Konf JOIN "Članice" ON  Konf."KonfederacijaID" = "Članice"."fk_KonfederacijaID" JOIN "Klubovi" ON "Klubovi"."ID_članice" = "Članice"."ČlanicaID" WHERE Konf."Ime_konfederacija" LIKE ' + vrijednost + ' OR Konf."Predsjednik_konfederacije" LIKE ' + vrijednost + ' OR Konf."Regija" LIKE ' + vrijednost + ' OR "Klubovi"."Ime_kluba" LIKE ' + vrijednost + ' OR "Klubovi"."Trener" LIKE ' + vrijednost + ' OR "Klubovi"."Stadion" LIKE ' + vrijednost + ' OR Članice."Ime_članice" LIKE ' + vrijednost + ' OR Članice."Predsjednik_članice" LIKE ' + vrijednost + ' OR Članice."Godina_osnutka_članice" LIKE ' + vrijednost + ';', [])).rows;
            }
        }
    } else {
        if (parametar == "Ime_konfederacija" || parametar == "Regija" || parametar == "Godina_osnutka_konfederacije" || parametar == "Predsjednik_konfederacije") {
            if (parametar != "Godina_osnutka_konfederacije") {
                parametar = "Konf." + "\"" + parametar + "\"";
                var rows = (await db.query('SELECT Konf."Ime_konfederacija", Konf."Predsjednik_konfederacije", Konf."Regija", Konf."Godina_osnutka_konfederacije", 	"Članice"."Ime_članice","Članice"."Predsjednik_članice", "Članice"."Godina_osnutka_članice", "Članice"."Godina_pristupanja_članice", 	"Klubovi"."Ime_kluba","Klubovi"."Godina_osnutka_kluba","Klubovi"."Stadion","Klubovi"."Trener"  	FROM "Konfederacije" as Konf JOIN "Članice" ON  Konf."KonfederacijaID" = "Članice"."fk_KonfederacijaID" JOIN "Klubovi" ON "Klubovi"."ID_članice" = "Članice"."ČlanicaID" WHERE ' + parametar + "LIKE '%" + vrijednost + "%';", [])).rows;
            } else {
                parametar = "Konf." + "\"" + parametar + "\"";
                n = parseInt(vrijednost)
                var rows = (await db.query('SELECT Konf."Ime_konfederacija", Konf."Predsjednik_konfederacije", Konf."Regija", Konf."Godina_osnutka_konfederacije", 	"Članice"."Ime_članice","Članice"."Predsjednik_članice", "Članice"."Godina_osnutka_članice", "Članice"."Godina_pristupanja_članice", 	"Klubovi"."Ime_kluba","Klubovi"."Godina_osnutka_kluba","Klubovi"."Stadion","Klubovi"."Trener"  	FROM "Konfederacije" as Konf JOIN "Članice" ON  Konf."KonfederacijaID" = "Članice"."fk_KonfederacijaID" JOIN "Klubovi" ON "Klubovi"."ID_članice" = "Članice"."ČlanicaID" WHERE ' + parametar + " = " + n + " ;", [])).rows;
            }
        } else if (parametar == "Ime_članice" || parametar == "Predsjednik_članice" || parametar == "Godina_osnutka_članice" || parametar == "Godina_pristupanja_članice") {
            if (parametar == "Ime_članice" || parametar == "Predsjednik_članice" || parametar == "Godina_osnutka_članice") {
                parametar = "Članice." + "\"" + parametar + "\"";
                console.log('SELECT Konf."Ime_konfederacija", Konf."Predsjednik_konfederacije", Konf."Regija", Konf."Godina_osnutka_konfederacije", "Članice"."Ime_članice","Članice"."Predsjednik_članice", "Članice"."Godina_osnutka_članice", "Članice"."Godina_pristupanja_članice", 	"Klubovi"."Ime_kluba","Klubovi"."Godina_osnutka_kluba","Klubovi"."Stadion","Klubovi"."Trener"  	FROM "Konfederacije" as Konf JOIN "Članice" ON  Konf."KonfederacijaID" = "Članice"."fk_KonfederacijaID" JOIN "Klubovi" ON "Klubovi"."ID_članice" = "Članice"."ČlanicaID" WHERE ' + parametar + " LIKE '%" + vrijednost + "%';");
                console.log('SELECT Konf."Ime_konfederacija", Konf."Predsjednik_konfederacije", Konf."Regija", Konf."Godina_osnutka_konfederacije", 	"Članice"."Ime_članice","Članice"."Predsjednik_članice", "Članice"."Godina_osnutka_članice", "Članice"."Godina_pristupanja_članice", 	"Klubovi"."Ime_kluba","Klubovi"."Godina_osnutka_kluba","Klubovi"."Stadion","Klubovi"."Trener"  	FROM "Konfederacije" as Konf JOIN "Članice" ON  Konf."KonfederacijaID" = "Članice"."fk_KonfederacijaID" JOIN "Klubovi" ON "Klubovi"."ID_članice" = "Članice"."ČlanicaID" WHERE ' + parametar + "LIKE '%" + vrijednost + "%';");
                var rows = (await db.query('SELECT Konf."Ime_konfederacija", Konf."Predsjednik_konfederacije", Konf."Regija", Konf."Godina_osnutka_konfederacije", 	"Članice"."Ime_članice","Članice"."Predsjednik_članice", "Članice"."Godina_osnutka_članice", "Članice"."Godina_pristupanja_članice", 	"Klubovi"."Ime_kluba","Klubovi"."Godina_osnutka_kluba","Klubovi"."Stadion","Klubovi"."Trener"  	FROM "Konfederacije" as Konf JOIN "Članice" ON  Konf."KonfederacijaID" = "Članice"."fk_KonfederacijaID" JOIN "Klubovi" ON "Klubovi"."ID_članice" = "Članice"."ČlanicaID" WHERE ' + parametar + "LIKE '%" + vrijednost + "%';", [])).rows;
            } else {
                parametar = "Članice." + "\"" + parametar + "\"";
                n = parseInt(vrijednost)
                var rows = (await db.query('SELECT Konf."Ime_konfederacija", Konf."Predsjednik_konfederacije", Konf."Regija", Konf."Godina_osnutka_konfederacije", 	"Članice"."Ime_članice","Članice"."Predsjednik_članice", "Članice"."Godina_osnutka_članice", "Članice"."Godina_pristupanja_članice", 	"Klubovi"."Ime_kluba","Klubovi"."Godina_osnutka_kluba","Klubovi"."Stadion","Klubovi"."Trener"  	FROM "Konfederacije" as Konf JOIN "Članice" ON  Konf."KonfederacijaID" = "Članice"."fk_KonfederacijaID" JOIN "Klubovi" ON "Klubovi"."ID_članice" = "Članice"."ČlanicaID" WHERE ' + parametar + " = " + n + " ;", [])).rows;
            }
        } else if (parametar == "Ime_kluba" || parametar == "Godina_osnutka_kluba" || parametar == "Stadion" || parametar == "Trener") {
            if (parametar == "Ime_kluba" || parametar == "Stadion" || parametar == "Trener") {
                console.log(parametar);
                parametar = "\"Klubovi\"." + "\"" + parametar + "\"";
                vrijednost = "\'" + vrijednost + "\'"
                var rows = (await db.query('SELECT Konf."Ime_konfederacija", Konf."Predsjednik_konfederacije", Konf."Regija", Konf."Godina_osnutka_konfederacije","Članice"."Ime_članice","Članice"."Predsjednik_članice", "Članice"."Godina_osnutka_članice", "Članice"."Godina_pristupanja_članice","Klubovi"."Ime_kluba","Klubovi"."Godina_osnutka_kluba","Klubovi"."Stadion","Klubovi"."Trener" FROM "Konfederacije" as Konf JOIN "Članice" ON  Konf."KonfederacijaID" = "Članice"."fk_KonfederacijaID" JOIN "Klubovi" ON "Klubovi"."ID_članice" = "Članice"."ČlanicaID" and ' + parametar + ' = ' + vrijednost + " ;", [])).rows;
            } else {
                parametar = "\"Klubovi\"." + "\"" + parametar + "\"";
                n = parseInt(vrijednost)
                var rows = (await db.query('SELECT Konf."Ime_konfederacija", Konf."Predsjednik_konfederacije", Konf."Regija", Konf."Godina_osnutka_konfederacije", 	"Članice"."Ime_članice","Članice"."Predsjednik_članice", "Članice"."Godina_osnutka_članice", "Članice"."Godina_pristupanja_članice", 	"Klubovi"."Ime_kluba","Klubovi"."Godina_osnutka_kluba","Klubovi"."Stadion","Klubovi"."Trener"  	FROM "Konfederacije" as Konf JOIN "Članice" ON  Konf."KonfederacijaID" = "Članice"."fk_KonfederacijaID" JOIN "Klubovi" ON "Klubovi"."ID_članice" = "Članice"."ČlanicaID" and ' + parametar + ' = ' + vrijednost + ";", [])).rows;
            }
        }

    }

    res.render('datatable_all.ejs', {
        title: 'FIFA PREGLED UPITA',
        data: rows
    })
});


module.exports = router;
const express = require('express');
const router = express.Router();
const db = require('../db/db');
const fs = require('fs');
module.exports = router;

router.get('/', async function (req, res, next) {
    var rows = (await db.query('SELECT Konf.\"Ime_konfederacija\", Konf.\"Predsjednik_konfederacije\", Konf.\"Regija\", Konf.\"Godina_osnutka_konfederacije\",\"Članice\".\"Ime_članice\",\"Članice\".\"Predsjednik_članice\", \"Članice\".\"Godina_osnutka_članice\", \"Članice\".\"Godina_pristupanja_članice\",\"Klubovi\".\"Ime_kluba\",\"Klubovi\".\"Godina_osnutka_kluba\",\"Klubovi\".\"Stadion\",\"Klubovi\".\"Trener\" FROM \"Konfederacije\" as Konf JOIN \"Članice\" ON  Konf.\"KonfederacijaID\" = \"Članice\".\"fk_KonfederacijaID\" JOIN \"Klubovi\" ON \"Klubovi\".\"ID_članice\" = \"Članice\".\"ČlanicaID\";')).rows;
    var status = validateRows(rows, res);

    if (status == 0) {
        res.set('content-type', 'application/json');
        res.status(200).send({
            status: "OK",
            message: "Svi podaci dohvaćeni!!!",
            response: rows
        });
    }
});

router.get('/klub/:id', async function (req, res, next) {
    let id = req.params.id;
    var status = validateID(id, res);

    if (status == 0) {
        var rows = (await db.query('SELECT \"Klubovi\".\"Ime_kluba\",\"Klubovi\".\"Godina_osnutka_kluba\",\"Klubovi\".\"Stadion\",\"Klubovi\".\"Trener\" FROM \"Klubovi\" WHERE \"Klubovi\".\"KlubID\" = ' + id)).rows;
        status = validateRows(rows, res);

        if (status == 0) {
            var obj = new Object();
            obj.context = "@context";
            obj.context.head = "headlink";
            rows[0].push({})
            console.log(rows[0])
            printStatus(res, "Klub", id, rows);
        }
    }
});

// Prva dodatna GET metoda - vrati određenu clanicu
router.get('/clanica/:id', async function (req, res, next) {
    let id = req.params.id;
    var status = validateID(id, res);

    if (status == 0) {
        var rows = (await db.query('SELECT \"Članice\".\"Ime_članice\",\"Članice\".\"Predsjednik_članice\", \"Članice\".\"Godina_osnutka_članice\", \"Članice\".\"Godina_pristupanja_članice\" FROM \"Članice\" WHERE \"Članice\".\"ČlanicaID\" = ' + id)).rows;
        status = validateRows(rows, res);

        //if (status == 0) printStatus(res, "Članica", id, rows);
        if (status == 0) printStatus_clanica(res, "Članica", id, rows);

    }
});

// Druga dodatna GET metoda - vrati konfederaciju s određenim id-om
router.get('/konf/:id', async function (req, res, next) {
    let id = req.params.id;
    var status = validateID(id, res);

    if (status == 0) {
        var rows = (await db.query('SELECT Konf.\"Ime_konfederacija\", Konf.\"Predsjednik_konfederacije\", Konf.\"Regija\", Konf.\"Godina_osnutka_konfederacije\" FROM \"Konfederacije\" as Konf WHERE Konf.\"KonfederacijaID\" = ' + id)).rows;
        status = validateRows(rows, res);

       // if (status == 0) printStatus(res, "Članica", id, rows);
       if (status == 0) printStatus_konfederacija(res, "Članica", id, rows);
    }
});
// Treća dodatna GET metoda - vrati sve klubove
router.get('/all_clubs/', async function (req, res, next) {
    var rows = (await db.query('SELECT \"Klubovi\".\"Ime_kluba\",\"Klubovi\".\"Godina_osnutka_kluba\",\"Klubovi\".\"Stadion\",\"Klubovi\".\"Trener\" FROM \"Klubovi\"')).rows;
    var status = validateRows(rows, res);

    if (status == 0) {
        res.set('content-type', 'application/json');
        res.status(200).send({
            status: "OK",
            message: "Svi klubovi dohvaćeni!!!",
            response: rows
        });
    }
});

router.delete('/delete_club/:id', async function (req, res, next) {
    let id = req.params.id;
    var status = validateID(id, res);

    if (status == 0) {
        try {
            var rows = (await db.query('SELECT \"Klubovi\".\"Ime_kluba\",\"Klubovi\".\"Godina_osnutka_kluba\",\"Klubovi\".\"Stadion\",\"Klubovi\".\"Trener\" FROM \"Klubovi\" WHERE \"Klubovi\".\"KlubID\" = ' + id)).rows;
            status = validateRows(rows, res);

            if (status == 0) {
                await db.query('DELETE FROM \"Klubovi\" WHERE \"KlubID\" = ' + id);
                res.set('content-type', 'application/json');
                res.status(200).send({
                    status: "OK",
                    message: `Klub ${id} obrisan!!!`
                });
            }
        } catch (err) {
            console.log(err);
            res.set('content-type', 'application/json');
            res.status(404).send({
                status: "Not Found",
                message: `Pogreška u brisanju!`
            });
        }
    }
});

router.post('/add_club', async function (req, res, next) {
    let id = req.query.id;
    var ime_kluba = req.query.ime_kluba;
    let godina_osnutka = req.query.godina_osnutka;
    let trener = req.query.trener;
    let stadion = req.query.stadion;
    let id_clanice = req.query.id_clanice;
    //var status = validateID(id, res);
    try {
        var rows = (await db.query('SELECT \"Klubovi\".\"Ime_kluba\",\"Klubovi\".\"Godina_osnutka_kluba\",\"Klubovi\".\"Stadion\",\"Klubovi\".\"Trener\" FROM \"Klubovi\" WHERE \"Klubovi\".\"KlubID\" = ' + id)).rows;
    } catch (err) {
        rows = null;
    }

    if (rows != null && rows != undefined && rows.length != 0) {
        res.set('content-type', 'application/json');
        res.status(404).send({
            status: "Not Found",
            message: `ID already exist`,
            response: null
        });
    }

    if (!isNaN(id) && id > 0) {
        try {
            console.log(godina_osnutka);

            rows = (await db.query('INSERT INTO \"Klubovi\" (\"KlubID\",\"Ime_kluba\", \"Godina_osnutka_kluba\", \"Trener\", \"Stadion\", \"ID_članice\") VALUES ($1, $2, $3, $4, $5, $6);', [id, ime_kluba, godina_osnutka, trener, stadion, id_clanice])).rows;

            res.set('content-type', 'application/json');
            res.status(200).send({
                status: "OK",
                message: `Klub s id ${id} dodan!!!`
            });

        } catch (err) {
            console.log(err);
            res.set('content-type', 'application/json');
            res.status(404).send({
                status: "Not Found",
                message: `Pogreška u upisivanju!`
            });
        }
    }
});

router.put('/update', async function (req, res, next) {
    let id = req.query.id;
    var ime_kluba = req.query.ime_kluba;
    let godina_osnutka = req.query.godina_osnutka;
    let trener = req.query.trener;
    let stadion = req.query.stadion;
    let id_clanice = req.query.id_clanice;

    if (req.query.id === "" || req.query.id_clanice === "" || req.query.godina_osnutka === "" ||
        req.query.stadion === "" || req.query.trener === "") {
        res.set('content-type', 'application/json');
        res.status(404).send({
            status: "Not Found",
            message: `Krivi parametri!!!`,
            response: null
        });
    } else {
        var zapis = (await db.query('SELECT * FROM \"Klubovi\" WHERE  \"KlubID\" = $1;', [id])).rows;
        if (zapis.length > 0) {
            try {
                (await db.query('UPDATE \"Klubovi\" SET \"Godina_osnutka_kluba\" = $1, \"ID_članice\" = $2, \"Ime_kluba\" = $3, \"Stadion\" = $4,\"Trener\" = $5 WHERE \"KlubID\" = $6; ', [godina_osnutka, id_clanice, ime_kluba, stadion, trener, id])).rows;

                res.set('content-type', 'application/json');
                res.status(200).send({
                    status: "OK",
                    message: `Klub s id ${id} update!!!`
                });
            } catch (err) {
                console.log(err);
                res.set('content-type', 'application/json');
                res.status(404).send({
                    status: "Not Found",
                    message: `Pogreška u upisivanju!`
                });
            }
        }
    }
});

router.get('/file/', async function (req, res, next) {
    let data = fs.readFileSync('openapi.json');

    res.set('content-type', 'application/json');
    res.status(200).send({
        status: "OK",
        message: "OpenAPI poslan!!!",
        response: JSON.parse(data)
    });
});

function validateID(id, res) {
    // check if ID is valid
    if (isNaN(id) || id < 0) {
        res.set('content-type', 'application/json');
        res.status(400).send({
            status: "Bad request",
            message: `ID is not a valid number`,
            response: null
        });

        return -1;
    } else {
        return 0;
    }
}

function validateRows(rows, res) {
    if (rows === null || rows === undefined || rows.length === 0) {
        res.set('content-type', 'application/json');
        res.status(404).send({
            status: "Not Found",
            message: `ID does not exist`,
            response: null
        });

        return -1;
    } else {
        return 0;
    }
}

function printStatus(res, name, id, rows) {
    res.set('content-type', 'application/json');
    res.status(200).send({
        status: "OK",
        message: name + ` s id ${id} postoji!`,
        response: rows
    });
}

schema_rows = {
    "@vocab": "http://schema.org/",
    "Ime_članice": "https://schema.org/Country",
    "Predsjednik_članice": "https://schema.org/name",
    "Godina_osnutka_članice": "https://schema.org/foundingDate",
}
function printStatus_clanica(res, name, id, rows) {
    res.set('content-type', 'application/json');
    res.status(200).send({
        status: "OK",
        message: name + ` s id ${id} postoji!`,
        '@context' : schema_rows,
        response: rows,
    });
}

schema_rows_conf = {
    "@vocab": "http://schema.org/",
    "Ime_konfederacija": "https://schema.org/legalName",
    "Predsjednik_konfederacije": "https://schema.org/name",
    "Godina_osnutka_konfederacije": "https://schema.org/foundingDate",
    "Regija" : "https://schema.org/Continent"
}
function printStatus_konfederacija(res, name, id, rows) {
    res.set('content-type', 'application/json');
    res.status(200).send({
        status: "OK",
        message: name + ` s id ${id} postoji!`,
        '@context' : schema_rows_conf,
        response: rows,
    });
}